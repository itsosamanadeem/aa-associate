# from . import account_move
from . import account_move_lines
from . import crm_trademark_history
from . import crm_inherit
from . import crm_trademark
from . import crm_trademark_history
from . import crm_label
from . import account_move_send_wizard
from . import account_payment_wizard
from . import crm_copyright
from . import account_move